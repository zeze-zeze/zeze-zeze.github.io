#!/usr/bin/env python3
"""The bbbttfb visitor: render one URL in Netscape and let go."""
import http.server
import json
import os
import queue
import re
import select
import shutil
import signal
import socket
import socketserver
import struct
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse

NETSCAPE = os.environ.get("NETSCAPE", "/opt/netscape/netscape.elf")
SLOTS    = int(os.environ.get("SLOTS", "4"))            # concurrent renders
TIMEOUT  = int(os.environ.get("RENDER_TIMEOUT", "45"))  # hard kill, seconds
MAXURL   = 4096
URL_OK   = re.compile(r"^https?://[^\s<>\"']{1,%d}$" % MAXURL)
PEER_UID = int(os.environ.get("VISITD_PEER_UID", "-1"))
PORT     = int(os.environ.get("PORT", "8080"))
SCREEN_W = 720
SCREEN_H = 728
REAP_EVERY = 1.0
PREFS_TEMPLATE = os.environ.get("PREFS_TEMPLATE",
                                "/opt/netscape/MCOM-preferences.template")
with open(PREFS_TEMPLATE) as _f:
    PREFS_BODY = _f.read()

_slots = queue.Queue()
for i in range(SLOTS):
    _slots.put(99 + i)
_conns = threading.Semaphore(int(os.environ.get("MAX_CONNS", "64")))


def _wait_x(env, deadline):
    """Wait until the display accepts a connection."""
    sock = "/tmp/.X11-unix/X" + env["DISPLAY"].lstrip(":")
    while time.time() < deadline:
        if os.path.exists(sock):
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try:
                s.connect(sock)
                return True
            except OSError:
                pass
            finally:
                s.close()
        time.sleep(0.05)
    return False


def _seed_prefs(home):
    """Write the preferences into this render's home."""
    with open(os.path.join(home, ".MCOM-preferences"), "w") as f:
        f.write(PREFS_BODY.replace("@HOME@", home))


def _reaper():
    """Collect orphans, which reparent here."""
    while True:
        try:
            while os.waitpid(-1, os.WNOHANG)[0]:
                pass
        except (ChildProcessError, OSError):
            pass
        time.sleep(REAP_EVERY)


def _reap_group(p, pgid=None):
    """Collect what a render's process group left behind.

    `pgid` must be read before the wait: after it the pid may name another group.
    """
    if not p:
        return
    if pgid is None:
        try:
            pgid = os.getpgid(p.pid)
        except OSError:
            return
    for _ in range(256):
        try:
            pid, _st = os.waitpid(-pgid, os.WNOHANG)
        except (ChildProcessError, OSError):
            return
        if pid == 0:
            return


def render(url, hold, present):
    """Spawn the browser on url, hold it while `hold()` says to, then take it
    down. Bounded by RENDER_TIMEOUT."""
    dpy = _slots.get()
    if not present():
        _slots.put(dpy)
        return "caller-gone (no slot came free)"
    disp = f":{dpy}"
    home = f"/tmp/ns-{dpy}"
    env = dict(PATH="/usr/bin:/bin", HOME=home, DISPLAY=disp,
               LD_LIBRARY_PATH="/lib", XKEYSYMDB="/opt/netscape/XKeysymDB",
               XAPPLRESDIR="/opt/netscape")
    xvfb = ns = None
    deadline = time.time() + TIMEOUT
    try:
        shutil.rmtree(home, ignore_errors=True)
        # 0.96b posts a modal notice the first time it creates its cache.
        os.makedirs(os.path.join(home, ".netscape"), exist_ok=True)
        os.makedirs(os.path.join(home, ".MCOM-cache"), exist_ok=True)
        _seed_prefs(home)
        xvfb = subprocess.Popen(
            ["Xvfb", disp, "-screen", "0", f"{SCREEN_W}x{SCREEN_H}x24",
             "-nolisten", "tcp"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            preexec_fn=os.setsid)
        if not _wait_x(env, min(deadline, time.time() + 10)):
            return "display-failed"
        logpath = os.path.join(home, "ns.log")
        with open(logpath, "wb") as lf:
            ns = subprocess.Popen(
                [NETSCAPE, "-geometry", f"{SCREEN_W}x{SCREEN_H}+0+0", url],
                env=env, stdout=lf, stderr=lf, preexec_fn=os.setsid)
            why = hold(ns, deadline)
        rc = ns.poll()
        if rc is not None:
            return f"browser-exited rc={rc}"
        # A render cut off at RENDER_TIMEOUT read the same as one the caller
        # ended, because the browser is alive either way.
        return "ok" if why != "deadline" else "render-timeout"
    finally:
        pgids = {}
        for p in (ns, xvfb):
            if p:
                try:
                    pgids[id(p)] = os.getpgid(p.pid)
                except OSError:
                    pgids[id(p)] = None
        for p in (ns, xvfb):
            if p and p.poll() is None:
                g = pgids.get(id(p))
                try:
                    if g is None:
                        raise OSError
                    os.killpg(g, signal.SIGKILL)
                except OSError:
                    try: p.kill()
                    except OSError: pass
        # The slot is the display number: not reusable until this server is gone.
        for p in (ns, xvfb):
            if p:
                try: p.wait(timeout=5)
                except Exception: pass
        _reap_group(ns, pgids.get(id(ns)))
        _reap_group(xvfb, pgids.get(id(xvfb)))
        for f in (f"/tmp/.X{dpy}-lock", f"/tmp/.X11-unix/X{dpy}"):
            try: os.unlink(f)
            except OSError: pass
        shutil.rmtree(home, ignore_errors=True)
        # SIGKILL cannot be blocked, so a server still here after five seconds is
        # stuck badly.
        if xvfb is not None and xvfb.poll() is None:
            sys.stderr.write(f"[visitd] display {dpy} would not die; "
                             f"slot withdrawn\n")
        else:
            _slots.put(dpy)


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *a):
        pass

    def _json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/health":
            return self._json(200, {"ok": True, "slots": SLOTS})
        if path == "/":
            return self._json(200, {"service": "bbbttfb visitor",
                                    "usage": "POST /visit url=<http url>"})
        return self._json(404, {"error": "not found"})

    def _present(self):
        """Whether the caller is still there."""
        try:
            ready, _w, _x = select.select([self.connection], [], [], 0)
            if not ready:
                return True
            return bool(self.connection.recv(1, socket.MSG_PEEK))
        except OSError:
            return False

    def _hold(self, proc, deadline):
        """Block until the caller goes, the browser exits, or the deadline."""
        try:
            pidfd = os.pidfd_open(proc.pid)
        except (AttributeError, OSError):
            pidfd = None
        watch = [self.connection] + ([pidfd] if pidfd is not None else [])
        try:
            while True:
                left = deadline - time.time()
                if left <= 0:
                    return "deadline"
                try:
                    ready, _w, _x = select.select(watch, [], [], left)
                except OSError:
                    return "caller went away"
                if not ready:
                    return "deadline"
                if pidfd is not None and pidfd in ready:
                    return "browser exited"
                try:
                    if not self.connection.recv(1, socket.MSG_PEEK):
                        return "caller went away"
                except OSError:
                    return "caller went away"
                # Unasked-for data: peeked, not read, and dropped so this cannot spin.
                watch = [f for f in watch if f is not self.connection]
        finally:
            if pidfd is not None:
                os.close(pidfd)

    def do_POST(self):
        if urllib.parse.urlparse(self.path).path != "/visit":
            return self._json(404, {"error": "not found"})
        n = int(self.headers.get("Content-Length") or 0)
        if n > 65536:
            return self._json(413, {"error": "too large"})
        raw = self.rfile.read(n).decode("utf-8", "replace")
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip()
        if ctype == "application/json":
            try: form = json.loads(raw or "{}")
            except ValueError: return self._json(400, {"error": "bad json"})
        else:
            form = {k: v[0] for k, v in urllib.parse.parse_qs(raw).items()}

        url = (form.get("url") or "").strip()
        if not URL_OK.match(url):
            return self._json(400, {"error": "url must be http(s) and under %d bytes" % MAXURL})
        try:
            status = render(url, self._hold, self._present)
        except Exception as e:
            sys.stderr.write(traceback.format_exc())
            return self._json(500, {"error": "render failed", "detail": str(e)[:200]})
        return self._json(200, {"status": status})


class UnixServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    """The visit daemon over a unix socket."""
    address_family = socket.AF_UNIX
    daemon_threads = True
    request_queue_size = 128

    def server_bind(self):
        if not str(self.server_address).startswith("\0"):
            try:
                os.unlink(self.server_address)
            except FileNotFoundError:
                pass
        socketserver.TCPServer.server_bind(self)

    def get_request(self):
        conn, _ = self.socket.accept()
        if PEER_UID >= 0:
            cred = conn.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED,
                                   struct.calcsize("3i"))
            _pid, uid, _gid = struct.unpack("3i", cred)
            if uid != PEER_UID:
                conn.close()
                raise BlockingIOError("not the proxy")
        return conn, ("unix", 0)

    def process_request(self, request, client_address):
        if not _conns.acquire(blocking=False):
            try: request.close()
            except OSError: pass
            return
        super().process_request(request, client_address)

    def shutdown_request(self, request):
        try:
            super().shutdown_request(request)
        finally:
            _conns.release()


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 128

    def process_request(self, request, client_address):
        if not _conns.acquire(blocking=False):
            try: request.close()
            except OSError: pass
            return
        super().process_request(request, client_address)

    def shutdown_request(self, request):
        try:
            super().shutdown_request(request)
        finally:
            _conns.release()


if __name__ == "__main__":
    try:
        os.makedirs("/tmp/.X11-unix", exist_ok=True)
        os.chmod("/tmp/.X11-unix", 0o1777)
    except OSError as e:
        sys.stderr.write(f"[boot] could not make /tmp/.X11-unix: {e}\n")

    threading.Thread(target=_reaper, daemon=True).start()
    sock = os.environ.get("VISITD_SOCKET", "")
    if sock:
        sys.stderr.write(f"[boot] serving on {sock}, for uid {PEER_UID}\n")
        UnixServer("\0" + sock[1:] if sock.startswith("@") else sock,
                   Handler).serve_forever()
    else:
        Server(("0.0.0.0", PORT), Handler).serve_forever()
